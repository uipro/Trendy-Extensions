<?php

    /**
     * For full documentation, please visit: http://docs.reduxframework.com/
     * For a more extensive sample-config file, you may look at:
     * https://github.com/reduxframework/redux-framework/blob/master/sample/sample-config.php
     */

    if ( ! class_exists( 'Redux' ) ) {
        return;
    }

    // This is your option name where all the Redux data is stored.
    $opt_name = "trendy_options";

    /**
     * ---> SET ARGUMENTS
     * All the possible arguments for Redux.
     * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
     * */

    $theme = wp_get_theme(); // For use with some settings. Not necessary.

    $args = array(
        'opt_name' => 'trendy_options',
        'display_name' => 'Trendy Theme Options',
        'display_version' => '1.0.0',
        'page_slug' => 'trendy_options',
        'page_title' => 'Theme Options',
        'update_notice' => TRUE,
        'admin_bar' => TRUE,
        'menu_type' => 'menu',
        'menu_title' => 'Theme Options',
        'menu_icon' => 'dashicons-art',
        'allow_sub_menu' => TRUE,
        'page_parent_post_type' => 'your_post_type',
        'page_priority' => '25',
        'customizer' => TRUE,
        'default_show' => TRUE,
        'default_mark' => '*',
        'class' => 'trendy-options',
        'hints' => array(
            'icon' => 'el el-question-sign',
            'icon_position' => 'right',
            'icon_color' => '#66abe8',
            'icon_size' => 'normal',
            'tip_style' => array(
                'color' => 'dark',
                'style' => 'bootstrap',
            ),
            'tip_position' => array(
                'my' => 'top center',
                'at' => 'top left',
            ),
            'tip_effect' => array(
                'show' => array(
                    'effect' => 'slide',
                    'duration' => '500',
                    'event' => 'mouseover',
                ),
                'hide' => array(
                    'effect' => 'slide',
                    'duration' => '500',
                    'event' => 'mouseleave unfocus',
                ),
            ),
        ),
        'output' => TRUE,
        'output_tag' => TRUE,
        'settings_api' => TRUE,
        'cdn_check_time' => '1440',
        'compiler' => TRUE,
        'page_permissions' => 'manage_options',
        'save_defaults' => TRUE,
        'show_import_export' => TRUE,
        'database' => 'options',
        'transient_time' => '3600',
        'network_sites' => TRUE,
		'disable_tracking' => TRUE,
		'dev_mode' => FALSE
    );

    Redux::setArgs( $opt_name, $args );

    /*
     * ---> END ARGUMENTS
     */

    /*
     * ---> START HELP TABS
     */

    $tabs = array(
        array(
            'id'      => 'redux-help-tab-1',
            'title'   => esc_html__( 'Theme Information 1', 'trendy-extensions' ),
            'content' => esc_html__( '<p>This is the tab content, HTML is allowed.</p>', 'trendy-extensions' )
        ),
        array(
            'id'      => 'redux-help-tab-2',
            'title'   => esc_html__( 'Theme Information 2', 'trendy-extensions' ),
            'content' => esc_html__( '<p>This is the tab content, HTML is allowed.</p>', 'trendy-extensions' )
        )
    );
    Redux::setHelpTab( $opt_name, $tabs );

    // Set the help sidebar
    $content = esc_html__( '<p>This is the sidebar content, HTML is allowed.</p>', 'trendy-extensions' );
    Redux::setHelpSidebar( $opt_name, $content );


    /*
     * <--- END HELP TABS
     */


    /*
     *
     * ---> START SECTIONS
     *
     */
	
	// header settings START
	 Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Header', 'trendy-extensions' ),
        'desc'       => esc_html__( 'All header related settings.', 'trendy-extensions' ),
        'id'         => 'page-header',
        'icon'   => 'el el-bell',
		'fields'     => array(
             array(
				'id'       => 'header-style',
				'type'     => 'image_select',
				'title'    => esc_html__( 'Header Style', 'trendy-extensions' ),
				'subtitle' => esc_html__( 'Choose your prefered header display style.', 'trendy-extensions' ),
				'options'  => array(
					'1' => array(
						'alt' => esc_html__( 'Centered logo with author info', 'trendy-extensions' ),
						'title' => esc_html__( 'Centered logo with author info', 'trendy-extensions' ),
						'img' => ReduxFramework::$_url . 'assets/img/centered-logo.jpg'
					),
					'2' => array(
						'alt' => esc_html__( 'Logo with banner ad', 'trendy-extensions' ),
						'title' => esc_html__( 'Logo with banner ad', 'trendy-extensions' ),
						'img' => ReduxFramework::$_url . 'assets/img/logo-ad.jpg'
					)
				),
				'default'  => '2'
			)
		)
     ));
	 Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Logo', 'trendy-extensions' ),
        'desc'       => esc_html__( 'Upload logo here.', 'trendy-extensions' ),
        'id'         => 'page-logo',
        'subsection' => true,
        'icon'   => 'el el-bulb',
		'fields'     => array(
             array(
                'id'       => 'trendy-logo',
                'type'     => 'media',
                'url'      => true,
                'title'    => esc_html__( 'Header Logo', 'trendy-extensions' ),
				'desc'     => esc_html__( 'Recomended logo size is 440x120 pixels.', 'trendy-extensions' ),
                'compiler' => 'true',
                'subtitle' => esc_html__( 'Upload your logo in JPG, PNG or GIF format.', 'trendy-extensions' )
            )
		)
     ));
	 Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Top Navigation Bar', 'trendy-extensions' ),
        'desc'       => esc_html__( 'Options to show/hide top navigation bar elements.', 'trendy-extensions' ),
        'id'         => 'page-top-nav',
        'subsection' => true,
        'icon'   => 'el el-bulb',
		'fields'     => array(
			array(
                'id'       => 'top-nav-show',
                'type'     => 'switch',
                'title'    => esc_html__( 'Show or Hide Entire Top Nav Bar ', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'You can enable or disable entire top nav bar section from here.', 'trendy-extensions' ),
                'default'  => 1,
                'on'       => 'SHOW',
                'off'      => 'HIDE',
            ),
			array(
                'id'       => 'trendy-date-tme',
                'type'     => 'switch',
				'required' => array( 'top-nav-show', '=', '1' ),
                'title'    => esc_html__( 'Show or Hide Current Date', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'You can show or hide current date display in top nav bar here.', 'trendy-extensions' ),
                'default'  => 1,
                'on'       => 'SHOW',
                'off'      => 'HIDE',
            ),
			array(
                'id'       => 'trendy-top-nav',
                'type'     => 'switch',
				'required' => array( 'top-nav-show', '=', '1' ),
                'title'    => esc_html__( 'Show or Hide Nav Menu', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'You can show or hide nav menu in top nav bar here.', 'trendy-extensions' ),
                'default'  => 1,
                'on'       => 'SHOW',
                'off'      => 'HIDE',
            ),
			array(
                'id'       => 'top-social-nav',
                'type'     => 'switch',
				'required' => array( 'top-nav-show', '=', '1' ),
                'title'    => esc_html__( 'Show or Hide Social Profiles\' links', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'You can show or hide your social profiles\' links in top nav bar here.', 'trendy-extensions' ),
                'default'  => 1,
                'on'       => 'SHOW',
                'off'      => 'HIDE',
            )
		)
     ));
	 Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Blog Author', 'trendy-extensions' ),
        'desc'       => esc_html__( 'You can add custom author photo, titel and some description here.', 'trendy-extensions' ),
        'id'         => 'blog-author',
        'subsection' => true,
        'icon'   => 'el el-bulb',
		'fields'     => array(
			array(
                'id'       => 'show-author',
                'type'     => 'switch',
                'title'    => esc_html__( 'Show or Hide Author Info', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'You can show or hide author info, from header section, here.', 'trendy-extensions' ),
                'default'  => 1,
                'on'       => 'SHOW',
                'off'      => 'HIDE',
            ),
			array(
                'id'       => 'author-thumbnail',
                'type'     => 'media',
                'url'      => true,
				'required' => array( 'show-author', '=', '1' ),
                'title'    => esc_html__( 'Author Thumbnail', 'trendy-extensions' ),
				'desc'     => esc_html__( 'Recomended thumbnail size is 120x120 pixels.', 'trendy-extensions' ),
                'compiler' => 'true',
                'subtitle' => esc_html__( 'Upload your image in JPG, PNG or GIF format.', 'trendy-extensions' )
            ),
			array(
                'id'       => 'author-name',
                'type'     => 'text',
				'required' => array( 'show-author', '=', '1' ),
                'title'    => esc_html__( 'Author Name', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'Enter author name or title.', 'trendy-extensions' ),
            ),
			array(
                'id'       => 'author-info',
                'type'     => 'textarea',
				'required' => array( 'show-author', '=', '1' ),
                'title'    => esc_html__( 'About Yourself', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'Introduce yourself in few words.', 'trendy-extensions' ),
            ),
			array(
                'id'       => 'profile-url',
                'type'     => 'text',
				'validate' => 'url',
				'required' => array( 'show-author', '=', '1' ),
                'title'    => esc_html__( 'Your Profile Link', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'Enter your profile link (optional).', 'trendy-extensions' ),
            )
		)
     ));
	 Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Featured Article', 'trendy-extensions' ),
        'desc'       => esc_html__( 'Featured Article will be shown in header section.', 'trendy-extensions' ),
        'id'         => 'featured-article',
        'subsection' => true,
        'icon'   => 'el el-bulb',
		'fields'     => array(
			array(
                'id'       => 'show-featured',
                'type'     => 'switch',
                'title'    => esc_html__( 'Show or Hide Featured Article', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'You can show or hide featured article section here.', 'trendy-extensions' ),
                'default'  => 1,
                'on'       => 'SHOW',
                'off'      => 'HIDE',
            ),
			array(
                'id'       => 'featured-slug',
                'type'     => 'text',
				'required' => array( 'show-featured', '=', '1' ),
                'title'    => esc_html__( 'Article Slug', 'trendy-extensions' ),
                'desc' => esc_html__( 'Enter post slug here.', 'trendy-extensions' )
            )
		)
     ));
	 Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Header Ad', 'trendy-extensions' ),
        'desc'       => esc_html__( 'Header ad settings..', 'trendy-extensions' ),
        'id'         => 'trendy-header-ad',
        'subsection' => true,
        'icon'   => 'el el-bulb',
		'fields'     => array(
             array(
                'id'       => 'header-ad',
                'type'     => 'switch',
                'title'    => esc_html__( 'Enable Header Ad', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'Header ad is optional, you can show or hide it from here.', 'trendy-extensions' ),
                'default'  => 1,
                'on'       => 'Enabled',
                'off'      => 'Disabled',
            ),
			array(
                'id'       => 'header-ad-image',
                'type'     => 'media',
				'required' => array( 'header-ad', '=', '1' ),
                'url'      => true,
                'title'    => esc_html__( 'Upload Ad Image', 'trendy-extensions' ),
                'compiler' => 'true',
                'subtitle' => esc_html__( 'Upload image in JPG, PNG or GIF format.', 'trendy-extensions' ),
				'desc'     => esc_html__( 'Recomended image size is 728x90 pixels.', 'trendy-extensions' )
            ),
			array(
                'id'       => 'header-ad-url',
                'type'     => 'text',
				'validate' => 'url',
				'required' => array( 'header-ad', '=', '1' ),
                'title'    => esc_html__( 'Enter Ad URL', 'trendy-extensions' ),
                'compiler' => 'true',
                'subtitle' => esc_html__( 'Enter ad url or referral link here.', 'trendy-extensions' )
            )
		)
     ));
	// header settings END
	
	
	// footer settings START
	 Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Footer', 'trendy-extensions' ),
        'desc'       => esc_html__( 'All footer related settings can be done from here.', 'trendy-extensions' ),
        'id'         => 'page-footer',
        'icon'   => 'el el-flag',
		'fields'     => array(
			array(
                'id'       => 'footer-social',
                'type'     => 'switch',
                'title'    => esc_html__( 'Footer Social Icons', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'Enable or disable social icons in footer section.', 'trendy-extensions' ),
                'default'  => 1,
                'on'       => 'ON',
                'off'      => 'OFF',
            ),
			array(
                'id'       => 'trendy-footer',
                'type'     => 'switch',
                'title'    => esc_html__( 'Show or Hide Entire Footer', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'You can enable or disable entire footer section from here.', 'trendy-extensions' ),
                'default'  => 1,
                'on'       => 'SHOW',
                'off'      => 'HIDE',
            ),
			array(
                'id'       => 'footer-logo',
                'type'     => 'media',
                'url'      => true,
				'required' => array( 'trendy-footer', '=', '1' ),
                'title'    => esc_html__( 'Footer Logo', 'trendy-extensions' ),
                'compiler' => 'true',
                'subtitle' => esc_html__( 'Upload your logo in JPG, PNG or GIF format.', 'trendy-extensions' )
            ),
			array(
                'id'       => 'footer-text',
                'type'     => 'textarea',
				'required' => array( 'trendy-footer', '=', '1' ),
                'title'    => esc_html__( 'Footer Description Text', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'Enter text explaing your blog and/or about yourself.', 'trendy-extensions' ),
            ),
			array(
                'id'       => 'trendy-copyright',
                'type'     => 'text',
				'required' => array( 'trendy-footer', '=', '1' ),
                'title'    => esc_html__( 'Copyright Text', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'Enter your custom copyright text here.', 'trendy-extensions' ),
                'desc'     => esc_html__( 'No need to include © character.', 'trendy-extensions' )
            ),
            array(
                'id'       => 'footer-ad',
                'type'     => 'switch',
				'required' => array( 'trendy-footer', '=', '1' ),
                'title'    => esc_html__( 'Enable Footer Ad', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'Footer ad is optional, you can show or hide it from here.', 'trendy-extensions' ),
                'default'  => 1,
                'on'       => 'Enabled',
                'off'      => 'Disabled',
            ),
			array(
                'id'       => 'footer-ad-image',
                'type'     => 'media',
				'required' => array( 'footer-ad', '=', '1' ),
                'url'      => true,
                'title'    => esc_html__( 'Upload Ad Image', 'trendy-extensions' ),
                'compiler' => 'true',
                'subtitle' => esc_html__( 'Upload image in JPG, PNG or GIF format.', 'trendy-extensions' )
            ),
			array(
                'id'       => 'footer-ad-url',
                'type'     => 'text',
				'required' => array( 'footer-ad', '=', '1' ),
                'title'    => esc_html__( 'Enter Ad URL', 'trendy-extensions' ),
                'compiler' => 'true',
                'subtitle' => esc_html__( 'Enter ad url or referral link here.', 'trendy-extensions' )
            )
		)
    ) );
	// footer settings END
	
	// homepage settings START
	 Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Home Page', 'trendy-extensions' ),
        'desc'       => esc_html__( 'All homepage related settings.', 'trendy-extensions' ),
        'id'         => 'home-page',
        'icon'   => 'el el-website',
		'fields'     => array(
             array(
				'id'       => 'homepage-layout',
				'type'     => 'select',
				'title'    => esc_html__( 'Home Page Layout', 'trendy-extensions' ),
				'subtitle' => esc_html__( 'Choose your prefered homepage layout.', 'trendy-extensions' ),
				'options'  => array(
					'sidebar_left' => 'Sidebar Left',
					'sidebar_right' => 'Sidebar Right',
					'no_sidebar' => 'No Sidebar',
					'fluid_template' => 'Full Width (fluid)',
				),
				'default'  => 'sidebar_right',
			),
			array(
                'id'       => 'home-slider',
                'type'     => 'switch',
                'title'    => esc_html__( 'Show or Hide Home Page Slider', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'You can enable or disable homepage slider from here.', 'trendy-extensions' ),
                'default'  => 1,
                'on'       => 'SHOW',
                'off'      => 'HIDE',
            ),
             array(
				'id'       => 'slider-post-option',
				'type'     => 'select',
				'required' => array( 'home-slider', '=', '1' ),
				'title'    => esc_html__( 'Display Posts By', 'trendy-extensions' ),
				'subtitle' => esc_html__( 'Choose an option, how posts will be displayed, in homepage slider.', 'trendy-extensions' ),
				'options'  => array(
					'recentely_published' => 'Recentely Published',
					'_post_like_count' => 'Most Liked',
					'comment_count' => 'Most Commented',
					'featured_posts' => 'Featured Posts',
				),
				'default'  => 'recentely_published',
			),
			array(
                'id'       => 'slider-post-count',
                'type'     => 'text',
				'required' => array( 'home-slider', '=', '1' ),
                'title'    => esc_html__( 'Posts Count', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'How many posts you would like to display in homepage slider?', 'trendy-extensions' ),
				 'desc'     => esc_html__( 'Default value is 5', 'trendy-extensions' ),
                'validate' => 'numeric',
				'default'  => '5',
            ),
             array(
				'id'       => 'slider-style',
				'type'     => 'select',
				'required' => array( 'home-slider', '=', '1' ),
				'title'    => esc_html__( 'Slider Style', 'trendy-extensions' ),
				'subtitle' => esc_html__( 'Choose homepage slider style.', 'trendy-extensions' ),
				'options'  => array(
					'single_slide' => 'Full Width Slide',
					'multi_slide' => 'Carousel (multiple slides)'
				),
				'default'  => 'single_slide',
			)
		)
     ));
	
	// blog settings START
	 Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Blog', 'trendy-extensions' ),
        'desc'       => esc_html__( 'Blog and single post settings.', 'trendy-extensions' ),
        'id'         => 'trendy-blog',
        'icon'   => 'el el-comment-alt',
		'fields'     => array(
             array(
                'id'       => 'sharing-options',
                'type'     => 'switch',
                'title'    => esc_html__( 'Social Sharing & Post Like Options', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'You can choose here, whether to show sharing options, beofre or after the post content.', 'trendy-extensions' ),
                'default'  => 1,
                'on'       => 'BEFORE CONTENT',
                'off'      => 'AFTER CONTENT',
            ),
			 array(
                'id'       => 'show-likes',
                'type'     => 'switch',
                'title'    => esc_html__( 'Post Likes', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'You can choose here, whether to show or hide post likes.', 'trendy-extensions' ),
                'default'  => 1,
                'on'       => 'SHOW',
                'off'      => 'HIDE',
            ),
			 array(
                'id'       => 'show-author-box',
                'type'     => 'switch',
                'title'    => esc_html__( 'Author Info Box', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'You can choose to show or hide author box, after post content, on each single post.', 'trendy-extensions' ),
                'default'  => 1,
                'on'       => 'SHOW',
                'off'      => 'HIDE',
            )
		)
     ));
	// blog settings END
	
	// social links START
	 Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Social Links', 'trendy-extensions' ),
        'desc'       => esc_html__( 'All social network links should be added from here.', 'trendy-extensions' ),
        'id'         => 'social',
        'icon'   => 'dashicons dashicons-share',
		'fields'     => array(
			array(
                'id'       => 'facebook',
                'type'     => 'text',
                'title'    => esc_html__( 'Facebook', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'Enter your facebook profile link here.', 'trendy-extensions' ),
                'validate' => 'url',
            ),
			array(
                'id'       => 'twitter',
                'type'     => 'text',
                'title'    => esc_html__( 'Twitter', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'Enter your twitter profile link here.', 'trendy-extensions' ),
                'validate' => 'url',
            ),
			array(
                'id'       => 'linkedin',
                'type'     => 'text',
                'title'    => esc_html__( 'Linkedin', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'Enter your linkedin profile link here.', 'trendy-extensions' ),
                'validate' => 'url',
            ),
			array(
                'id'       => 'pinterest',
                'type'     => 'text',
                'title'    => esc_html__( 'Pinterest', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'Enter your pinterest profile link here.', 'trendy-extensions' ),
                'validate' => 'url',
            ),
			array(
                'id'       => 'google-plus',
                'type'     => 'text',
                'title'    => esc_html__( 'Google Plus', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'Enter your google+ profile link here.', 'trendy-extensions' ),
                'validate' => 'url',
            ),
			array(
                'id'       => 'youtube',
                'type'     => 'text',
                'title'    => esc_html__( 'Youtube', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'Enter your youtube profile link here.', 'trendy-extensions' ),
                'validate' => 'url',
            ),
			array(
                'id'       => 'tumblr',
                'type'     => 'text',
                'title'    => esc_html__( 'Tumblr', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'Enter your tumblr profile link here.', 'trendy-extensions' ),
                'validate' => 'url',
            ),
			array(
                'id'       => 'instagram',
                'type'     => 'text',
                'title'    => esc_html__( 'Instagram', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'Enter your instagram profile link here.', 'trendy-extensions' ),
                'validate' => 'url',
            ),
			array(
                'id'       => 'reddit',
                'type'     => 'text',
                'title'    => esc_html__( 'Reddit', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'Enter your reddit profile link here.', 'trendy-extensions' ),
                'validate' => 'url',
            ),
			array(
                'id'       => 'flickr',
                'type'     => 'text',
                'title'    => esc_html__( 'Flickr', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'Enter your flickr profile link here.', 'trendy-extensions' ),
                'validate' => 'url',
            ),
			array(
                'id'       => 'dribbble',
                'type'     => 'text',
                'title'    => esc_html__( 'Dribbble', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'Enter your dribbble profile link here.', 'trendy-extensions' ),
                'validate' => 'url',
            ),
			array(
                'id'       => 'vimeo',
                'type'     => 'text',
                'title'    => esc_html__( 'Vimeo', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'Enter your vimeo profile link here.', 'trendy-extensions' ),
                'validate' => 'url',
            ),
			array(
                'id'       => 'soundcloud',
                'type'     => 'text',
                'title'    => esc_html__( 'Soundcloud', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'Enter your soundcloud profile link here.', 'trendy-extensions' ),
                'validate' => 'url',
            ),
			array(
                'id'       => 'vk',
                'type'     => 'text',
                'title'    => esc_html__( 'vk', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'Enter your vk profile link here.', 'trendy-extensions' ),
                'validate' => 'url',
            ),
			array(
                'id'       => 'behance',
                'type'     => 'text',
                'title'    => esc_html__( 'Behance', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'Enter your behance profile link here.', 'trendy-extensions' ),
                'validate' => 'url',
            ),
			array(
                'id'       => 'github',
                'type'     => 'text',
                'title'    => esc_html__( 'GitHub', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'Enter your github profile link here.', 'trendy-extensions' ),
                'validate' => 'url',
            )
		)
    ) );
	// social links END
	
	
	// theme color options START
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Accent Color', 'trendy-extensions' ),
        'id'         => 'trendy-theme-colors',
        'desc'       => esc_html__( 'You can select your preferred theme accent color here.', 'trendy-extensions' ),
        'icon'  => 'el el-brush',
        'fields'     => array(
            array(
                'id'       => 'trendy-accent-color',
                'type'     => 'color',
                'title'    => esc_html__( 'Accent Color', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'Choose your preferred custom theme accent color.', 'trendy-extensions' ),
                'default'  => '#f83030',
            )
        ),
    ) );
	
	
	// theme typography settings
    Redux::setSection( $opt_name, array(
        'title'  => esc_html__( 'Typography', 'trendy-extensions' ),
        'id'     => 'typography',
        'desc'   => esc_html__( 'Typography options allows you to enable and choose custom google fonts for your website.', 'trendy-extensions' ),
        'icon'   => 'el el-font',
        'fields' => array(
            array(
                'id'       => 'trendy-custom-fonts',
                'type'     => 'switch',
                'title'    => esc_html__( 'Custom Google Fonts', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'You can enable custom google fonts for your theme here.', 'trendy-extensions' ),
                'default'  => 0,
                'on'       => 'Custom Fonts',
                'off'      => 'Default Fonts',
            ),
			array(
                'id'			=> 'trendy-default-font',
                'type'			=> 'typography',
				'required' => array( 'trendy-custom-fonts', '=', '1' ),
                'title'			=> esc_html__( 'Body Font', 'trendy-extensions' ),
                'subtitle' 		=> esc_html__( 'This is default font for most of the page elements.', 'trendy-extensions' ),
                'output'      	=> array( 'body, blockquote cite' ),
                'units'       	=> 'px',
                'google'		=> true,
				'all_styles'	=> true,
				'font-size'     => false,
				'font-style'    => false,
				'line-height'   => false,
				'color'         => false,
				'text-align'    => false,
				'font-weight'	=> false
            ),
			array(
                'id'			=> 'trendy-alt-font',
                'type'			=> 'typography',
				'required' => array( 'trendy-custom-fonts', '=', '1' ),
                'title'			=> esc_html__( 'Alternate Font', 'trendy-extensions' ),
                'subtitle' 		=> esc_html__( 'This font will be used for italics, blockquote etc.', 'trendy-extensions' ),
				'desc'       => esc_html__( 'You can apply this font style to your markup using "alt-font" class and for italics us "em" class.', 'trendy-extensions' ),
                'output'      	=> array( '.alt-font, .em, em, blockquote > p' ),
                'units'       	=> 'px',
                'google'		=> true,
				'all_styles'	=> true,
				'font-size'     => false,
				'font-style'    => false,
				'line-height'   => false,
				'color'         => false,
				'text-align'    => false,
				'font-weight'	=> false
            ),
			array(
                'id'			=> 'trendy-heading-font',
                'type'			=> 'typography',
				'required' => array( 'trendy-custom-fonts', '=', '1' ),
                'title'			=> esc_html__( 'Headings Font', 'trendy-extensions' ),
                'subtitle' 		=> esc_html__( 'This font will apply on all headings from H1 to H6.', 'trendy-extensions' ),
				'desc'       => esc_html__( 'You can also apply heading font styles to any text element using .h1, .h2, .h3, .h4, .h5, .h6 heading classes.', 'trendy-extensions' ),
                'output'      	=> array( 'h1, .h1, h2, .h2, h3, .h3, h4, .h4, h5, .h5, h6, .h6' ),
                'units'       	=> 'px',
                'google'		=> true,
				'all_styles'	=> true,
				'font-size'     => false,
				'font-style'    => false,
				'line-height'   => false,
				'color'         => false,
				'text-align'    => false,
				'font-weight'	=> false
            )
        )
    ) );
	
	// custom css
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Custom CSS', 'trendy-extensions' ),
        'id'         => 'trendy-custom-css',
        'icon'  => 'el el-edit',
        'desc'       => esc_html__( 'This section allows you to enter your own custom CSS styles.', 'trendy-extensions' ),
        'fields'     => array(
            array(
                'id'       => 'trendy-css-editor',
                'type'     => 'ace_editor',
                'title'    => esc_html__( 'CSS Code', 'trendy-extensions' ),
                'subtitle' => esc_html__( 'Paste your CSS code here.', 'trendy-extensions' ),
                'mode'     => 'css',
                'theme'    => 'monokai',
            )
        )
    ) );

    /*
     * <--- END SECTIONS
     */

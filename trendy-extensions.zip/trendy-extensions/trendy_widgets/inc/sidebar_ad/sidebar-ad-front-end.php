<div class="aside-widget ad-widget">
	<div class="widget-inner">
		<a class="banner-ad" href="<?php echo esc_url( $ad_link ); ?>" title="<?php echo esc_html__( 'sponsor', 'trendy-extensions' ); ?>"><img src="<?php echo esc_url( $ad_img_url ); ?>" alt="<?php echo esc_html__( 'sponsor', 'trendy-extensions' ); ?>"></a>
	</div>
</div>
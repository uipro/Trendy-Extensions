<?php	
	echo $before_widget;
	if ( !empty( $about_title ) ) {
		echo $before_title . $about_title . $after_title;
	}
?>
<div class="about-me">
<p class="my-thumb">
	<a href="<?php echo esc_url( $about_profile ); ?>" title="<?php echo esc_html__( 'Author', 'trendy-extensions' ); ?>">
		<img src="<?php echo esc_url( $about_img_url ); ?>" alt="<?php echo esc_html__( 'Author', 'trendy-extensions' ); ?>">
	</a>
</p>
<p><?php echo $about_intro; ?></p>
<p class="signature"><img src="<?php echo esc_url( $about_signature ); ?>" alt="<?php echo esc_html__( 'signature', 'trendy-extensions' ); ?>"></p>
</div>
<?php echo $after_widget; ?>



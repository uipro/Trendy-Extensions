<p>
	<label>Title</label>
	<input class="widefat" name="<?php echo $this->get_field_name('campaign_monitor_title'); ?>" type="text" value="<?php echo $campaign_monitor_title; ?>">
</p>
<p>
	<label>Sub Title</label>
	<input class="widefat" name="<?php echo $this->get_field_name('campaign_monitor_sub_title'); ?>" type="text" value="<?php echo $campaign_monitor_sub_title; ?>">
</p>
<p>
	<label>Form Action URL</label>
	<input class="widefat" name="<?php echo $this->get_field_name('campaign_monitor_form_url'); ?>" type="text" value="<?php echo $campaign_monitor_form_url; ?>">
	<br /><small><a href="http://help.campaignmonitor.com/topic.aspx?t=13&_ga=1.87017880.1228675726.1423415182" title="How to get campaign monitor form action url?" target="_blank">How to get campaign_monitor form action url?</a></small>
</p>
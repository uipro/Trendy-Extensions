<?php	
	echo $before_widget;
	$add_sub_title = NULL;
	if ( !empty( $campaign_monitor_sub_title ) ){
		$add_sub_title = '<p class="widget-sub-title">' . $campaign_monitor_sub_title . '</p>';
	}
	if ( !empty( $campaign_monitor_title ) ) {
		echo $before_title . $campaign_monitor_title . $after_title;
	}
	echo $add_sub_title;
?>

<form class="subscription-form" id="sub-form" action="<?php echo $campaign_monitor_form_url ?>" method="post">
	<div class="form-group">
		<input type="email" class="form-control" id="email" name="cm-hkdrul-hkdrul" placeholder="Enter Email..." required>
	</div>
	<button type="submit" class="btn btn-primary btn-block">Subscribe</button>
</form>

<?php echo $after_widget; ?>